class GroupcommentsController < ApplicationController

	def create
		@grouppost = Grouppost.find(params[:grouppost_id])
		@groupcomment = @grouppost.groupcomments.create(params[:groupcomment].permit(:name, :body))
		redirect_to grouppost_path(@grouppost)		
	end

	def destroy
		@grouppost = Grouppost.find(params[:grouppost_id])
		@groupcomment = @grouppost.groupcomments.find(params[:id])
		@groupcomment.destroy
		redirect_to groupposts_path(@grouppost)
	end

end
