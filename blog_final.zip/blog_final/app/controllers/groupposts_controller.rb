class GrouppostsController < ApplicationController
	before_action :authenticate_user!, except: [:index, :show]

	def index
		@groupposts = Grouppost.where('group_id IN (?)', params[:group_id])
	end

	def new
		@grouppost = Grouppost.new
	end

	def create
		
		@grouppost = Grouppost.new(grouppost_params)
		if @grouppost.save
			
			redirect_to @grouppost
		else
			render 'new'
		end
	end

	def show
		@grouppost = Grouppost.find(params[:id])
	end

	def edit
		@grouppost = Grouppost.find(params[:id])
	end

	def update
		@grouppost = Grouppost.find(params[:id])
		if @grouppost.update(params[:post].permit(:title, :body))
			redirect_to @grouppost
		else
			render 'edit'
		end
	end

	def destroy
		@grouppost = Grouppost.find(params[:id])
		@grouppost.destroy
		redirect_to groupposts_path
	end


	private
		def grouppost_params
			params.require(:grouppost).permit(:group_id, :title, :body)	
		end	

end
