class ManagerController < ApplicationController
  
  before_action :authenticate_user!

  def index
  	@groupposts = Grouppost.all.order("created_at DESC")
  end
  
end
