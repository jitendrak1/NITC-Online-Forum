class RequestnewgroupsController < ApplicationController

	before_action :authenticate_user!, except: [:index, :create, :show]

	def index
		@requestnewgroups = Requestnewgroup.all.order('created_at DESC')
		@member = Member.all		
	end

	def new
		@requestnewgroup = Requestnewgroup.new
	end

	def create		
		@requestnewgroup = Requestnewgroup.new(requestnewgroup_params)
	
		if @requestnewgroup.save			
			groupID = @requestnewgroup.id
			userID = current_user.id
			@member = Member.create(group_id: groupID, user_id: userID, group_manager: true)

			redirect_to @requestnewgroup
		else
			render 'new'
		end	

		@member.save
	end

	
	def joingroups
		groupID = params[:group_id]
		userID = current_user.id
		@member = Member.create(group_id: groupID, user_id: userID, group_manager: false)
	end

	def show
		@requestnewgroup = Requestnewgroup.find(params[:id])
	end

	def is_not_join?
		gID = params[:g_id]
		uID = params[:u_id]
		return Member.where('group_id = ? AND user_id = ?',gID, uID)
	end
 
	private	

		def requestnewgroup_params
			params.require(:requestnewgroup).permit(:groupname,:groupdescription)
		end 		
end
