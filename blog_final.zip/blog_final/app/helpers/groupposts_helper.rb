module GrouppostsHelper
end
