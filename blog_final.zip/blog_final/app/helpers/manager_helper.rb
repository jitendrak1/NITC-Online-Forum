module ManagerHelper
end
