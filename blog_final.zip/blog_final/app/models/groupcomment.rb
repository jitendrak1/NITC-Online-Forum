class Groupcomment < ActiveRecord::Base
  belongs_to :grouppost
end
