class Grouppost < ActiveRecord::Base

	#change
	belongs_to :requestnewgroup

	has_many :groupcomments, dependent: :destroy
	#validation for title and body
	validates :title, presence: true, length: { minimum: 10}
	validates :body, presence: true
end
