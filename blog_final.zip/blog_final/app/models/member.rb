class Member < ActiveRecord::Base
	belongs_to :requestnewgroup	
end
