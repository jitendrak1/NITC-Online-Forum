class Post < ActiveRecord::Base
	#set post have many comments (when post is delete then comments is also delete (dependent: : destroy))
	has_many :comments, dependent: :destroy

	#validation for title and body
	validates :title, presence: true, length: { minimum: 10}
	validates :body, presence: true

	def self.search(query)
		where('title like :pat or body like :pat', :pat => "%#{query}%")		
	end
end
