class Requestnewgroup < ActiveRecord::Base
	has_many :members

	#change
	has_many :groupposts  
end
