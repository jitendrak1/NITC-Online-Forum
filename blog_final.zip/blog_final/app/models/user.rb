class User < ActiveRecord::Base
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable and :omniauthable
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :trackable, :validatable

  def check_admin?
    self.check.eql?('admin')
  end

  def check_manager?
    self.check.eql?('manager')
  end

  def check_user?
    self.check.eql?('user')
  end

end
