class AddRollNoToUsers < ActiveRecord::Migration
  def change
    add_column :users, :rollno, :string
    add_column :users, :name, :string
    add_column :users, :course, :string
    add_column :users, :department, :string
    add_column :users, :check, :string, :default=>'user'
  end
end
