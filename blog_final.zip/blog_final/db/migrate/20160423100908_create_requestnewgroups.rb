class CreateRequestnewgroups < ActiveRecord::Migration
  def change
    create_table :requestnewgroups do |t|
      t.string :groupname
      t.string :groupdescription
     	
      t.timestamps null: false
    end
  end
end
