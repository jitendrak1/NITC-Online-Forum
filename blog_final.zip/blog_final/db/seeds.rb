# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)

# add default admin user

User.create(email: 'admin@nitc.ac.in', password: '123123123', rollno: 'A130290CA', name: 'JAM', course: 'Security', department: 'Computer', check: 'admin')

User.create(email: 'manager@nitc.ac.in', password: '123123123', rollno: 'A130211CA', name: 'deepak', course: 'MBA', department: 'Manage', check: 'manager')