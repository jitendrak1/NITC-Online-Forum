require 'test_helper'

class GrouppostsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
