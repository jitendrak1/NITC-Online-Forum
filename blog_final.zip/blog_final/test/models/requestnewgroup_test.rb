require 'test_helper'

class RequestnewgroupTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
